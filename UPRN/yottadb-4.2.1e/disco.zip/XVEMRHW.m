XVEMRHW ;DJB/VRR**Help Text - Web [12/14/96 6:34pm];2017-08-15  1:48 PM
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 ; Original Code authored by David J. Bolduc 1985-2005
 ;
WEB ;;;
 ;;; Insert HTML code onto new lines
 ;;; ---------------------------------------------------------------------------
 ;;; xxx ...... Generic          <xxx></xxx>
 ;;; C ........ Comment          <!-- -->
 ;;; I ........ Image            <IMG SRC="IMAGES/X.GIF">
 ;;; L ........ List             <UL><LI>
 ;;; LK ....... Link             <A HREF="DOC.HTM">Click Here
 ;;; R ........ Required tags    <HTML><HEADER><TITLE><BODY>
 ;;; T ........ Table            <TABLE><TR><TD>
 ;;;
 ;;; Insert HTML code into current line (preceed code with ".")
 ;;; ---------------------------------------------------------------------------
 ;;; .xxx ..... Generic       <xxx>
 ;;; .AQUA    238E68    .GREEN  00FF00    .PURPLE 871F78    .YELLOW FFFF00
 ;;; .BLACK   000000    .LIME   32CD32    .RED    FF0000
 ;;; .BLUE    0000FF    .MAROON 8E236B    .SILVER 545454
 ;;; .FUCHSIA FF00FF    .NAVY   23238E    .TEAL   00FFFF
 ;;; .GRAY    C0C0C0    .OLIVE  238E23    .WHITE  FFFFFF
 ;;;***
