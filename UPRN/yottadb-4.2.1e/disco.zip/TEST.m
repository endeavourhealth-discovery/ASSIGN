TEST ; ; 1/24/20 9:57am
 W !,"ADDRESS: "
 R A
 D GETUPRN^UPRNMGR(A)
 S json=^temp($j,1)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 zwr b
 S L=b("ABPAddress","Locality")
 S N=b("ABPAddress","Number")
 S POST=b("ABPAddress","Postcode")
 S STRT=b("ABPAddress","Street")
 S TWN=b("ABPAddress","Town")
 S A=b("Algorithm")
 S C=b("Classification")
 S PBUILD=b("Match_pattern","Building")
 S PFLAT=b("Match_pattern","Flat")
 S PNUM=b("Match_pattern","Number")
 S PPOST=b("Match_pattern","Postcode")
 Q
