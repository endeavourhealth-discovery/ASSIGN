ADR ; ; 5/17/23 5:08pm
 quit
 
STT ;
 k ^TPARAMS($J)
 S ^S(1)=$HOROLOG
 S f="/tmp/download-e.txt"
 S f2="/tmp/download-e-out.txt"
 c f,f2
 o f:(readonly)
 o f2:(newversion)
 ;u f r str,str
 s c=1
 f  u f r str q:$zeof!(str="")  do
 .s ADREC=$p(str,"~",2,99)
 .S ADREC=$$TR^LIB(ADREC,"~",",")
 .D GETUPRN^UPRNMGR(ADREC,"","","",0,0)
 .S id=$p(str,"~",1)
 .k b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .S CLASS=$GET(b("Classification"))
 .S CLASSDESC=$GET(b("ClassTerm"))
 .S QUAL=$GET(b("Qualifier"))
 .S ALG=$GET(b("Algorithm"))
 .;u 0 w !,ADREC
 .;U 0 W !,UPRN," ",CLASS," ",QUAL," ",ALG
 .;U 0 R *Y
 .use f2 w ADREC,"~",UPRN,"~",CLASS,"~",QUAL,"~",ALG,!
 .i c#100=0 u 0 w !,c
 .s c=c+1
 .quit
 c f,f2
 S ^S(2)=$HOROLOG
 quit
