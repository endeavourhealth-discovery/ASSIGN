XVVMI00R ; ; 04-JAN-2004
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 F I=1:2 S X=$T(Q+I) Q:X=""  S Y=$E($T(Q+I+1),4,999),X=$E(X,4,999) S:$A(Y)=126 I=I+1,Y=$E(Y,2,999)_$E($T(Q+I+1),5,99) S:$A(Y)=61 Y=$E(Y,2,999) X NO E  S @X=Y
Q Q
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",9,9)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",10,10)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",11,11)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",12,19)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",13,12)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",14,20)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",15,13)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",16,22)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",17,14)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",18,21)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",19,15)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",20,23)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",21,16)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",22,24)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",23,17)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",24,25)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",25,18)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",26,26)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",27,27)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",28,28)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"B",29,29)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",1,3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",2,4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",3,5)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",4,9)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",5,11)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",6,12)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",7,13)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",8,14)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",9,15)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",10,16)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",11,17)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",12,18)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C",13,27)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C","DESCRIPTION",29)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"C","FM CALL",2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,"D","VALUE1",6)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,0)
 ;;=XVVM PER HD^19200.111^
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,0)
 ;;=^.4044I^3^3
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,1,0)
 ;;=1^Edit PERSON^1
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,1,2)
 ;;=^^1,34
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,2,0)
 ;;=2^Page 1 of 1^1
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,2,2)
 ;;=^^1,68
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,3,0)
 ;;=3^------------------------------------------------------------------------------^1
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,3,2)
 ;;=^^2,1
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"B",1,1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"B",2,2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"B",3,3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"C","---------------------------------------------------------------",3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"C","EDIT PERSON",1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",965,40,"C","PAGE 1 OF 1",2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,0)
 ;;=XVVM PER EDT^19200.111
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,0)
 ;;=^.4044I^4^4
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,1,0)
 ;;=1^NAME^3
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,1,1)
 ;;=.01
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,1,2)
 ;;=3,29^30^3,23
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,2,0)
 ;;=2^INITIALS^3
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,2,1)
 ;;=2
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,2,2)
 ;;=4,29^5^4,19
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,3,0)
 ;;=3^VPE ID^3
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,3,1)
 ;;=3
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,3,2)
 ;;=5,29^9^5,21
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,4,0)
 ;;=4^ROUTINE VERSIONING PROMPT^3
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,4,1)
 ;;=4
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,4,2)
 ;;=6,29^3^6,2
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"B",1,1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"B",2,2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"B",3,3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"B",4,4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"C","INITIALS",2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"C","NAME",1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"C","ROUTINE VERSIONING PROMPT",4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",966,40,"C","VPE ID",3)
 ;;=
 ;;^UTILITY(U,$J,"PKG",19,0)
 ;;=VPE SHELL^XVVM^Victory Programmer Environment
 ;;^UTILITY(U,$J,"PKG",19,1,0)
 ;;=^^2^2^3040104^^^^
 ;;^UTILITY(U,$J,"PKG",19,1,1,0)
 ;;=This is the Victory Programmer Environment package developed and
 ;;^UTILITY(U,$J,"PKG",19,1,2,0)
 ;;=distributed by David Bolduc.
 ;;^UTILITY(U,$J,"PKG",19,4,0)
 ;;=^9.44PA^5^5
 ;;^UTILITY(U,$J,"PKG",19,4,1,0)
 ;;=19200.113
 ;;^UTILITY(U,$J,"PKG",19,4,1,222)
 ;;=y^^^y^^^y^o^y
 ;;^UTILITY(U,$J,"PKG",19,4,2,0)
 ;;=19200.114
