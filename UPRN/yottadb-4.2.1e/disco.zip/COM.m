COM ; ; 2/5/21 1:53pm
 K ^TPARAMS($J)
 S F="/tmp/100000.txt",C=0
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO  ;;Q:C>10
 .S ADR=$P(STR,",",2,9999)
 .S ^TPARAMS($J,"commercials")=1
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .S UPRN=$get(b("UPRN"))
 .S C=C+1
 .I C#1000=0 U 0 W !,C
 .QUIT
 C F
 QUIT
