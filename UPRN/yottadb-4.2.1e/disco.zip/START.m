START ; ; 1/31/23 3:03pm
 D SETUP^UPRNHOOK2
 D ^UPRNUI2
 D ^REG2
 w !,"starting web server"
 j START^VPRJREQ(9081,"","dev")
 w !,"started"
 quit
 
STOP K ^VPRHTTP
 w !,"stopped"
 QUIT
