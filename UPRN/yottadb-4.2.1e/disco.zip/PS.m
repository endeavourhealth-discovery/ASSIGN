PS ; ; 6/5/23 9:48am
 quit
ADNAN ;
 s u="c180870c-e78d-4aa3-bf4a-c4bb5d259833"
 s f="/opt/files/ASSIGN_RECORDS.txt"
 s l=""
 S f2="/tmp/adnan.txt"
 c f2
 o f2:(newversion)
 use f2
 f  s l=$o(^NGX(u,f,l)) q:l=""  do
 .w !,^(l)
 .quit
 close f2
 quit
 
 new f2,id,uprn
 s f2="/tmp/epc23_output_qual_LIVE.txt"
 c f2
 o f2:(newversion)
 set id=""
 f  s id=$order(^GILL(id)) q:id=""  do
 .S rec=^(id)
 .s uprn=$p(rec,"~",1),qual=$p(rec,"~",2)
 .use f2 w id,$c(9),uprn,$c(9),qual,!
 .quit
 close f2
 quit
 
RUN new f,f2,str,adrec,id,uprn
 k ^TPARAMS($J)
 k ^GILL
 s f="/tmp/epc23.txt"
 ;s f2="/tmp/epc23_output.txt"
 close f
 ;close f2
 o f:(readonly)
 ;o f2:(newversion)
 f  u f r str q:$zeof  do
 .S str=$TR(str,$c(13),"")
 .set str=$$TR^LIB(str,"""","")
 .set adrec=$p(str,$c(9),2)
 .set id=$p(str,$c(9),1)
 .do GETUPRN^UPRNMGR(adrec)
 .set uprn=$o(^TUPRN($J,"MATCHED",""),-1)
 .s table=$O(^TUPRN($j,"MATCHED",uprn,""),-1)
 .s key=$O(^TUPRN($J,"MATCHED",uprn,table,""),-1)
 .S matchrec=$get(^TUPRN($j,"MATCHED",uprn,table,key))
 .S qual=$$qual^UPRN2(matchrec)
 .;use 0 w !,$o(^TUPRN($J,"MATCHED",""),-1) read *y
 .i id#1000=0 use 0 w !,id
 .;use f2 w id,$c(9),uprn,!
 .S ^GILL(id)=uprn_"~"_qual
 .;USE 0 W !,"PRESS A KEY:" R *Y
 .quit
 close f
 ;close f2
 quit
 
UMATCH ;
 s f="/tmp/umatch.txt"
 close f
 o f:(readonly)
 S f2="/tmp/umatch_chk.txt"
 close f2
 o f2:(newversion)
 f  u f r str q:$zeof  do
 .s uprn=$p(str,$c(9),1)
 .s odscode=$p(str,$c(9),2)
 .s odsadr=$p(str,$c(9),3)
 .use f2
 .w uprn,$c(9),odscode,$c(9),odsadr,!
 .s key=""
 .f z="D","L" do
 ..f  s key=$o(^UPRN("U",uprn,z,key)) q:key=""  do
 ...s rec=$get(^UPRN("U",uprn,z,key,"O"))
 ...i rec="" quit
 ...w z,$c(9),key,$c(9),rec,!
 ...quit
 .w !
 .quit
 close f,f2
 quit
 
SEL ; sel care homes
 quit
 
 s f="/tmp/sel_file.txt"
 c f
 o f:(readonly)
 s f2="/tmp/sel_carehomes.txt"
 c f2
 o f2:(newversion)
 f  u f r str q:$zeof  do
 .use 0 w !,str
 .k ^TPARAMS($J)
 .S ADR=$P(str,$c(9),3)
 .S ODS=$P(str,$c(9),2)
 .S COUNT=$p(str,$c(9),4)
 .;w !,ADR
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .;W !,^temp($j,1)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .S CLASS=$GET(b("Classification"))
 .S CLASSDESC=$GET(b("ClassTerm"))
 .S QUAL=$GET(b("Qualifier"))
 .S ALG=$GET(b("Algorithm"))
 .;w !
 .;zwr b
 .;w !
 .use f2 write ODS,$C(9),ADR,$C(9),UPRN,$C(9),CLASS,$C(9),CLASSDESC,$C(9),QUAL,$C(9),ALG,$c(9),COUNT,!
 .;r *y
 .quit
 close f,f2
 quit
 
 S A="",C=0
 F  S A=$O(^CQC(A)) Q:A=""  DO
 .S J=""
 .F I=1:1:10 S J1=$G(^CQC(A,I)) Q:J1=""  S J=J_J1
 .;W !,J R *Y
 .D DECODE^VPRJSON($name(J),$name(b),$name(err))
 .S ADR=$get(b("address",1,"text"))
 .;W !,ADR R *Y
 .K ^TPARAMS($J),^TUPRN($J)
 .S ^TPARAMS($J,"commercials")=1
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .;W !,^temp($j,1)
 .S C=C+1
 .I C#1000=0 W !,C
 .QUIT
 QUIT
 
 K ^NELPOST
 S F="/tmp/POSTCODE_ABP_CCG.txt"
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO
 .S ^NELPOST($TR(STR,$C(13),""))=""
 .QUIT
 CLOSE F
 QUIT
 
CQC K ^CQC
 ;S F="/tmp/UPRN3_globals/CQC.gs"
 S F="/tmp/CQC.gs"
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .;U 0 R *Y
 .U F R DATA
 .;U 0 W !,STR
 .;U 0 W !,DATA
 .;U 0 R *Y
 .;S X=$$TR^LIB(STR,"""","""""")
 .;X STR
 .S X="S "_STR_"=DATA"
 .X X
 .U 0 W "."
 .QUIT
 C F
 QUIT
 
CLR ;
 S A=""
 F  S A=$O(^CQC(A)) Q:A=""  DO
 .S H=+^CQC(A,"H")
 .I H'=65763 K ^CQC(A)
 .QUIT
 Q
 
 S A=""
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO
 .S REC=^(A)
 .S DAT=$P(REC,"|",4)
 .S CONFIG=$P($P(REC,"|",2),"`",2)
 .I $P(DAT,",",1)=65552 W !,CONFIG," * ",DAT R *Y
 .QUIT
 QUIT
 
 K ^PS
 S (A,B)=""
 F  S A=$O(^UPRN(A)) Q:A=""  D
 .F  S B=$O(^UPRN(A,B)) Q:B=""  D
 ..S ^PS(A)=$G(^PS(A))+1
 ..Q
 .QUIT
 W $D
 QUIT
