XVEMDH3 ;DJB/VEDD**Help Text - Main Menu [7/19/95 9:14pm];2017-08-15  12:07 PM
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 ; Original Code authored by David J. Bolduc 1985-2005
 ;
VEDD1 ;;;
 ;;;
 ;;;     11) Required Fields  - Lists all fields that are Required.
 ;;;
 ;;;     12) VGL - Victory Global Lister. To use this option your DUZ(0) must
 ;;;               must contain '@' or '#'.
 ;;;
 ;;;     13) Printing-On/Off  - Allows you to send screens to a printer. You
 ;;;                            will be offered the DEVICE: prompt. Enter printer.
 ;;;                            After <RETURN>, Main Menu will reappear and
 ;;;                            PRINTING STATUS, in the top half of the screen,
 ;;;                            will be set to 'ON'. You then select a Main
 ;;;                            Menu option and output will go to the selected
 ;;;                            device. When you return to the Main Menu,
 ;;;                            PRINTING STATUS will be 'OFF'. To print again
 ;;;                            you must select Printing On/Off option again
 ;;;                            to reset PRINTING STATUS to 'ON'. If PRINTING
 ;;;                            STATUS is 'ON' you may turn it off by selecting
 ;;;                            Printing On/Off option again. To slave
 ;;;                            print, enter '0;;60' at the DEVICE: prompt.
 ;;;
 ;;;                            NOTE: Since all screens are designed to be
 ;;;                            displayed on a CRT, printing to a 10 pitch
 ;;;                            80 margin printer looks best.
 ;;;***
