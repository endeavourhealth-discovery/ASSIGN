GFIND ; ; 4/1/20 8:52am
 N glb,str,query
 R "Which global? ",glb,!
 R "String? ",str,!
 F  S glb=$q(@glb) Q:glb=""  D
 .I glb[str!(@glb[str) W !,glb,"=",@glb
 .Q
 Q
