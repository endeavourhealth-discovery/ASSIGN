XVVMI005 ; ; 04-JAN-2004
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 Q:'DIFQ(19200.113)  F I=1:2 S X=$T(Q+I) Q:X=""  S Y=$E($T(Q+I+1),4,999),X=$E(X,4,999) S:$A(Y)=126 I=I+1,Y=$E(Y,2,999)_$E($T(Q+I+1),5,99) S:$A(Y)=61 Y=$E(Y,2,999) X NO E  S @X=Y
Q Q
 ;;^DD(19200.113,28,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,28,"DT")
 ;;=2960107
 ;;^DD(19200.113,29,0)
 ;;=PARAM 9^*P19200.114'^XVV(19200.114,^P;9^S DIC("S")="I $P(^(0),U,2)'=""n""" D ^DIC K DIC S DIC=DIE,X=+Y K:Y<0 X
 ;;^DD(19200.113,29,12)
 ;;=Screen inactive parameters.
 ;;^DD(19200.113,29,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,29,"DT")
 ;;=2960107
 ;;^DD(19200.113,30,0)
 ;;=PARAM 10^*P19200.114'^XVV(19200.114,^P;10^S DIC("S")="I $P(^(0),U,2)'=""n""" D ^DIC K DIC S DIC=DIE,X=+Y K:Y<0 X
 ;;^DD(19200.113,30,12)
 ;;=Screen inactive parameters.
 ;;^DD(19200.113,30,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,30,"DT")
 ;;=2960107
 ;;^DD(19200.113,31,0)
 ;;=PARAM 11^*P19200.114'^XVV(19200.114,^P;11^S DIC("S")="I $P(^(0),U,2)'=""n""" D ^DIC K DIC S DIC=DIE,X=+Y K:Y<0 X
 ;;^DD(19200.113,31,12)
 ;;=Screen inactive parameters.
 ;;^DD(19200.113,31,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,31,"DT")
 ;;=2960107
 ;;^DD(19200.113,32,0)
 ;;=PARAM 12^*P19200.114'^XVV(19200.114,^P;12^S DIC("S")="I $P(^(0),U,2)'=""n""" D ^DIC K DIC S DIC=DIE,X=+Y K:Y<0 X
 ;;^DD(19200.113,32,12)
 ;;=Screen inactive parameters.
 ;;^DD(19200.113,32,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,32,"DT")
 ;;=2960107
 ;;^DD(19200.113,33,0)
 ;;=PARAM 13^*P19200.114'^XVV(19200.114,^P;13^S DIC("S")="I $P(^(0),U,2)'=""n""" D ^DIC K DIC S DIC=DIE,X=+Y K:Y<0 X
 ;;^DD(19200.113,33,12)
 ;;=Screen inactive parameters.
 ;;^DD(19200.113,33,12.1)
 ;;=S DIC("S")="I $P(^(0),U,2)'=""n"""
 ;;^DD(19200.113,33,"DT")
 ;;=2960107
 ;;^DD(19200.113,61,0)
 ;;=VALUE 1^F^^V1;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,61,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,61,4)
 ;;=
 ;;^DD(19200.113,61,"DT")
 ;;=2960107
 ;;^DD(19200.113,62,0)
 ;;=VALUE 2^F^^V2;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,62,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,62,"DT")
 ;;=2960107
 ;;^DD(19200.113,63,0)
 ;;=VALUE 3^F^^V3;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,63,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,63,"DT")
 ;;=2960107
 ;;^DD(19200.113,64,0)
 ;;=VALUE 4^F^^V4;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,64,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,64,"DT")
 ;;=2960107
 ;;^DD(19200.113,65,0)
 ;;=VALUE 5^F^^V5;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,65,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,65,"DT")
 ;;=2960107
 ;;^DD(19200.113,66,0)
 ;;=VALUE 6^F^^V6;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,66,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,66,"DT")
 ;;=2960107
 ;;^DD(19200.113,67,0)
 ;;=VALUE 7^F^^V7;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,67,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,67,"DT")
 ;;=2960107
 ;;^DD(19200.113,68,0)
 ;;=VALUE 8^F^^V8;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,68,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,68,"DT")
 ;;=2960107
 ;;^DD(19200.113,69,0)
 ;;=VALUE 9^F^^V9;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,69,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,69,"DT")
 ;;=2960107
 ;;^DD(19200.113,70,0)
 ;;=VALUE 10^F^^V10;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,70,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,70,"DT")
 ;;=2960107
 ;;^DD(19200.113,71,0)
 ;;=VALUE 11^F^^V11;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,71,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,71,"DT")
 ;;=2960107
 ;;^DD(19200.113,72,0)
 ;;=VALUE 12^F^^V12;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,72,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,72,"DT")
 ;;=2960107
 ;;^DD(19200.113,73,0)
 ;;=VALUE 13^F^^V13;E1,245^K:$L(X)>245!($L(X)<1) X
 ;;^DD(19200.113,73,3)
 ;;=Answer must be 1-245 characters in length.
 ;;^DD(19200.113,73,"DT")
 ;;=2960107
