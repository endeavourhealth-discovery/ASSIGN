NULLUPRNS ; ; 3/9/22 1:05pm
 ;n file
 QUIT
 
STT ;
 S F="/tmp/missing_nel_gp.txt"
 CLOSE F
 O F:(readonly)
 
 KILL ^TPARAMS($J)
 S C=1
 F  U F R STR Q:$ZEOF  DO
 .S CADR=$P(STR,"~",2,99)
 .K B
 .D GETUPRN^UPRNMGR(CADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .S UPRN=$G(B("UPRN"))
 .I UPRN'="" u 0 w !,"[",UPRN,"] ",CADR R *Y
 .I C#1000=0 U 0 W !,C
 .S C=C+1
 .QUIT
 CLOSE F
 QUIT
 
STT2 KILL
 s file="/tmp/null-uprns.txt"
 close file
 o file:(readonly)
 set D=$c(9)
 KILL ^TPARAMS($J)
 
 S F2="/tmp/null-uprns-output.txt"
 CLOSE F2
 O F2:(newversion)
 
 use file r STR ; header
 for  use file r STR q:$zeof  do
 .;u 0 w !,str
 .set STR=$$TR^LIB(STR,$c(13),"")
 .set ID=$p(STR,D,1)
 .set ADD1=$p(STR,D,2)
 .i ADD1="NULL" set ADD1=""
 .set ADD2=$p(STR,D,3)
 .i ADD2="NULL" s ADD2=""
 .set ADD3=$p(STR,D,4)
 .i ADD3="NULL" s ADD3=""
 .set ADD4=$p(STR,D,5)
 .if ADD4="NULL" s ADD4=""
 .set POSTCODE=$P(STR,D,6)
 .if POSTCODE="NULL" s POSTCODE=""
 .s CADR=ADD1_","_ADD2_","_ADD3_","_ADD4_","_POSTCODE
 .;u 0 w !,CADR r *y
 .K B
 .D GETUPRN^UPRNMGR(CADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .S UPRN=$G(B("UPRN"))
 .u 0 w !,"[",UPRN,"] ",CADR
 .USE F2 W UPRN,$C(9),ADD1,$C(9),ADD2,$C(9),ADD3,$C(9),ADD4,$C(9),POSTCODE,!
 .;
 .quit
 close file,F2
 quit
