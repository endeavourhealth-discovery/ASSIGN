EPOCH76 ; ; 8/4/20 2:59pm
 K ^NULL,^MISMATCH
 S T=0,MISMATCH=0
 S F="/tmp/epoch76/ID28_DPA_Records.csv"
 C F
 O F:(readonly)
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .S ADR=""
 .F I=6:1:16 DO
 ..S DATA=$TR($P(STR,",",I),"""","")
 ..S ADR=ADR_DATA_","
 ..QUIT
 .S DPAUPRN=$P(STR,",",4)
 .S ADR=$E(ADR,1,$L(ADR)-1)
 .;U 0 W !,ADR R *Y
 .K B,^temp($j)
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .S UPRN=$G(B("UPRN"))
 .;I UPRN="" S T=T+1 U 0 W !,"NULL" S ^NULL(DPAUPRN)=ADR
 .I DPAUPRN'=UPRN S ^MISMATCH(DPAUPRN)=UPRN_"|"_ADR
 .QUIT
 C F
 QUIT
 
DUMP ;
 S F="/tmp/mismatch-epoch76.csv"
 C F
 O F:(writeonly)
 S DPAUPRN=""
 U F W "ID28_UPRN,UPRN,CAND_ADDR",!
 F  S DPAUPRN=$O(^MISMATCH(DPAUPRN)) Q:DPAUPRN=""  DO
 .S REC=^(DPAUPRN)
 .S UPRN=$P(REC,"|")
 .S ADDRESS=$P(REC,"|",2)
 .U F W DPAUPRN,",",UPRN,",""",ADDRESS,"""",!
 .QUIT
 C F
 QUIT
