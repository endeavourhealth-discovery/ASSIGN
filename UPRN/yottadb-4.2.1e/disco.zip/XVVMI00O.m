XVVMI00O ; ; 04-JAN-2004
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 F I=1:2 S X=$T(Q+I) Q:X=""  S Y=$E($T(Q+I+1),4,999),X=$E(X,4,999) S:$A(Y)=126 I=I+1,Y=$E(Y,2,999)_$E($T(Q+I+1),5,99) S:$A(Y)=61 Y=$E(Y,2,999) X NO E  S @X=Y
Q Q
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,14,2)
 ;;=10,54^25^10,45
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,15,0)
 ;;=15^PARAM 9^3
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,15,1)
 ;;=29
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,15,2)
 ;;=11,15^25^11,6
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,16,0)
 ;;=16^PARAM 10^3
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,16,1)
 ;;=30
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,16,2)
 ;;=11,54^25^11,44
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,17,0)
 ;;=17^PARAM 11^3
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,17,1)
 ;;=31
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,17,2)
 ;;=12,15^25^12,5
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,18,0)
 ;;=19^PARAM 13^3
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,18,1)
 ;;=33
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,18,2)
 ;;=13,15^25^13,5
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,19,0)
 ;;=18^PARAM 12^3
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,19,1)
 ;;=32
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,19,2)
 ;;=12,54^25^12,44
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",1,1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",2,2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",3,5)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",4,4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",5,3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",6,6)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",7,7)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",8,8)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",9,9)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",10,10)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",11,11)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",12,12)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",13,13)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",14,14)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",15,15)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",16,16)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",17,17)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",18,19)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"B",19,18)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","ACTIVE",2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","DESCRIPTION",5)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","IDENTIFIER",3)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","NAME",1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 1",7)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 10",16)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 11",17)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 12",19)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 13",18)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 2",8)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 3",9)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 4",10)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 5",11)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 6",12)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 7",13)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 8",14)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","PARAM 9",15)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","ROUTINE",6)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",716,40,"C","TYPE",4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,0)
 ;;=XVVM PGM CALL HD^19200.113^
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,0)
 ;;=^.4044I^6^5
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,1,0)
 ;;=1^CONSTRUCT & INSERT PROGRAMMER CALL^1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,1,2)
 ;;=^^1,23
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,2,0)
 ;;=2^Page 1 of 1^1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,2,2)
 ;;=^^1,68
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,4,0)
 ;;=4^!M^1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,4,.1)
 ;;=S Y=$S($P($G(^XVV(19200.113,DA,0)),U,4)'="v":"Parameter:",1:"Variable:")
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,4,2)
 ;;=^^4,5
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,5,0)
 ;;=5^Value:^1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,5,2)
 ;;=^^4,32
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,6,0)
 ;;=3^-------------------------------------------------------------------------------^1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,6,2)
 ;;=^^2,1
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"B",1,1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"B",2,2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"B",3,6)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"B",4,4)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"B",5,5)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"C","---------------------------------------------------------------",6)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"C","CONSTRUCT & INSERT PROGRAMMER CALL",1)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"C","PAGE 1 OF 1",2)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",717,40,"C","VALUE:",5)
 ;;=
 ;;^UTILITY(U,$J,"DIST(.404,",718,0)
 ;;=XVVM PGM CALL EDT^19200.113
 ;;^UTILITY(U,$J,"DIST(.404,",718,40,0)
 ;;=^.4044I^29^28
