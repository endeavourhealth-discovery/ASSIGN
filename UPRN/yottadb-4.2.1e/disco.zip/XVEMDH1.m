XVEMDH1 ;DJB/VEDD**Help Text - Main Menu [06/07/94];2017-08-15  12:07 PM
 ;;15.1;VICTORY PROG ENVIRONMENT;;Jun 19, 2019
 ; Original Code authored by David J. Bolduc 1985-2005
 ;
VEDD1 ;;;
 ;;; A)  E N T R Y   P O I N T S:
 ;;;
 ;;;        ^XVEMD  - Main entry point.
 ;;;     DIR^XVEMD  - Bypasses opening screen.
 ;;;
 ;;; B)  M E N U   O P T I O N S:
 ;;;
 ;;;     1) Cross References - An '*' in the far left column indicates that if
 ;;;                           you concantenate the global shown on the Main Menu
 ;;;                           screen with this XREF, there will be data.
 ;;;
 ;;;     2) Pointers IN - Lists all files that point to this file.
 ;;;
 ;;;     3) Pointers OUT - Lists all fields in this file that are pointers and
 ;;;                       the files they point to. An 'M' in the far left
 ;;;                       column indicates the pointing field is a multiple.
 ;;;                       Use 'Trace a Field' to determine its path.
 ;;;
 ;;;     4) Groups - In Filemanager Groups are a shorthand way for a user to
 ;;;                 call up several fields at once for Print or Entrer/Edit
 ;;;                 purposes. Also, some programmers use Groups to keep track
 ;;;                 of locally added/alterred fields. See VA FILEMAN USER'S
 ;;;                 MANUAL to learn how to use Groups.
 ;;;***
