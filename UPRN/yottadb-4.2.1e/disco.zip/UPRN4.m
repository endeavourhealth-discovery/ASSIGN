UPRN4 ;Import routine [ 03/10/2019  1:23 PM ]
 
 ;
 d files^UPRN1
 i country="" q
 B
 D IMPADNO^UPRN1
 Q
