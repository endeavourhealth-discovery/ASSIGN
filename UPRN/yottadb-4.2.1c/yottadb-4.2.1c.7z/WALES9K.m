WALES9K ; ; 7/30/20 1:57pm
 S F="/tmp/Addresses_Carmarthenshire (1).csv"
 S F2="/tmp/Addresses_Carmarthenshire (1)-output.csv"
 C F
 O F:(readonly)
 O F2:(newversion)
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .S ID=$P(STR,",",1)
 .S CADR=$P(STR,",",3,999)
 .S CADR=$TR(CADR,$C(13),"")
 .S CADR=$TR(CADR,"""","")
 .K B,^temp($j)
 .D GETUPRN^UPRNMGR(CADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .S ALG=$G(B("Algorithm"))
 .S MPBUILD=$G(B("Match_pattern","Building"))
 .S MPFLAT=$G(B("Match_pattern","Flat"))
 .S MPNUM=$G(B("Match_pattern","Number"))
 .S MPPCODE=$G(B("Match_pattern","Postcode"))
 .S QUAL=$G(B("Qualifier"))
 .S UPRN=$G(B("UPRN"))
 .I UPRN="" S ^PS($O(^PS(""),-1)+1)=CADR
 .U F2 W ID,",",ALG,",",MPBUILD,",",MPFLAT,",",MPNUM,",",MPPCODE,",",QUAL,",",UPRN,",""",CADR,",""",!
 .QUIT
 C F,F2
 QUIT
