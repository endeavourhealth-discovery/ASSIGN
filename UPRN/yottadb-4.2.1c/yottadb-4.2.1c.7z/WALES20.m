WALES20 ; ; 7/30/20 9:48am
 S F="/tmp/PRE-WelshCareHomes2020.txt"
 S F2="/tmp/WALES2020-output.txt"
 C F,F2
 O F:(readonly)
 O F2:(newversion)
 S T=0
 U F2 W "ID,ALG,MPBUILD,MPFLAT,MPNUM,MPPCODE,QUAL,UPRN,ADDRESS",!
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .;S ADR=$P(STR,",",3,999)
 .;S ADR=$TR(ADR,"""")
 .S ADR=$P(STR,"~",2)
 .S ADR=$TR(ADR,$C(13),"")
 .I ADR="" QUIT
 .S ID=$P(STR,"~",1)
 .;U 0 W !,ADR
 .K B,^temp($j)
 .;U 0 W !
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .;U 0 R *Y
 .S ALG=$G(B("Algorithm"))
 .S MPBUILD=$G(B("Match_pattern","Building"))
 .S MPFLAT=$G(B("Match_pattern","Flat"))
 .S MPNUM=$G(B("Match_pattern","Number"))
 .S MPPCODE=$G(B("Match_pattern","Postcode"))
 .S QUAL=$G(B("Qualifier"))
 .S UPRN=$G(B("UPRN"))
 .I UPRN="" S T=T+1
 .;U 0 W !
 .U F2 W ID,",",ALG,",",MPBUILD,",",MPFLAT,",",MPNUM,",",MPPCODE,",",QUAL,",",UPRN,",""",ADR,",""",!
 .;U 0 R *Y
 .QUIT
 C F,F2
 QUIT
