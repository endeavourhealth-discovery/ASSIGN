DS ; ; 5/11/21 1:52pm
 QUIT
 
ZCEG ;
 S F="/tmp/zceg.txt"
 C F
 O F:(newversion)
 S ADR=""
 F  S ADR=$O(^CEG(ADR)) Q:ADR=""  DO
 .U F W ADR,!
 .QUIT
 CLOSE F
 QUIT
 
K S A="",C=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S C=C+1
 .I C#100000=0 W !,A
 .K ^AUDIT(A)
 .QUIT
 QUIT
 
B S F="/tmp/archive_audit_280321.txt"
 C F
 O F:(newversion)
 S A="",C=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .U F W ^(A),!
 .S C=C+1
 .I C#10000=0 U 0 W !,C
 .QUIT
 CLOSE F
 QUIT
 
 K ^TPARAMS($J)
 S F="/tmp/100000.txt",C=0
 S F2="/tmp/100000_out_uprn2_4.2.1C_AFTER.txt"
 C F2
 C F
 O F:(readonly)
 O F2:(newversion)
 F  U F R STR Q:$ZEOF  DO  ;;Q:C>10
 .S ADR=$P(STR,",",2,9999)
 .;U 0 W !,ADR
 .;R *Y
 .; COMMERCIALS NOT SET (OH, YES IT IS)
 .S ^TPARAMS($J,"commercials")=1
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .S UPRN=$get(b("UPRN"))
 .U F2 W !,UPRN,"~",ADR,"~",$g(^temp($j,1))
 .S C=C+1
 .I C#1000=0 U 0 W !,C
 .QUIT
 CLOSE F,F2
 QUIT
 
 ; 50,000 RANDOM ADDRESSES
 ; TEST
 S F="/tmp/100000.txt"
 C F
 O F:(newversion):0
 S A=""
 F  S A=$O(^TP(A)) Q:A=""  D
 .S REC=^(A)
 .S UPRN=$P(REC,"|")
 .S ADR=$TR($P(REC,"|",3),$C(10),"")
 .;I ADR="" BREAK
 .U F W UPRN,",",ADR,!
 .QUIT
 C F
 QUIT
 
EXPCEGENT ;
 S F="/tmp/CEGENT.txt"
 C F
 O F:(newversion)
 S A=""
 F  S A=$O(^CEGENT(A)) Q:A=""  D
 .S REC=^(A)
 .U F W A,"|",$P(REC,"|",1,3),!
 .QUIT
 C F
 QUIT
 
STT K ^TP
 S TOT=0
 F I=1:1 DO  Q:TOT>100000
 .S Z=$R(15000000)
 .I $D(^TP(Z)) Q
 .S REC=$GET(^AUDIT(Z))
 .I REC["@" Q
 .I $P(REC,"|",3)="" QUIT
 .S CONFIG=$P($P(REC,"|",2),"`",3)
 .I CONFIG'="ceg_enterprise" QUIT
 .S ^TP(Z)=REC
 .S TOT=TOT+1
 .I TOT#1000=0 W !,TOT
 .QUIT
 Q
 
CEGENT ;
 K ^CEGENT
 S A=""
 F  S A=$O(^AUDIT(A)) Q:A=""  D
 .S REC=$G(^AUDIT(A))
 .S CONFIG=$P($P(REC,"|",2),"`",3)
 .I CONFIG'="ceg_enterprise" QUIT
 .S ^CEGENT(A)=REC
 .QUIT
 QUIT
 
 S A="",DIFF=0,TOT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^AUDIT(A)
 .S ADR=$P(REC,"|",3)
 .;W !,ADR R *Y
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .;w !,UPRN," AUDIT = ",$P(REC,"|")
 .;R *Y
 .I UPRN'=$P(REC,"|") W !,UPRN,"'=",$P(REC,"|",1)," * ",A," * ",ADR S DIFF=DIFF+1 ; R *Y
 .S TOT=TOT+1
 .QUIT
 QUIT
 
NOPE ;
 ;S F="/tmp/nope_internal_nel_gp.txt"
 S F="/tmp/nope_ceg_gp.txt"
 ;
 CLOSE F
 O F:(readonly)
 S C=1
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .K ^TPARAMS($J)
 .D GETUPRN^UPRNMGR(STR,"","","",0,0)
 .;U 0 W !,$GET(^temp($j,1)) R *Y
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .S UPRN=$get(b("UPRN"))
 .I UPRN'="" DO
 ..U 0 W !,STR,!,$G(^temp($j,1))
 ..S ^CEG(STR)=""
 ..QUIT
 .I C#100=0 U 0 W !,C
 .S C=C+1
 .QUIT
 CLOSE F
 QUIT
 
A R !,"ADDRESS: ",ADR
 W !
 K ^TPARAMS($J)
 S ^TPARAMS($J,"commercials")=1
 D GETUPRN^UPRNMGR(ADR,"","","",0,1)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 S UPRN=$get(b("UPRN"))
 W !,$P($GET(^UPRN("U",UPRN)),"~",7)
 S X=$P($GET(^UPRN("U",UPRN)),"~",7)
 S LAT=$P(X,",",3),LONG=$P(X,",",4)
 ;W !,LAT,",",LONG
 W !,"http://maps.google.com/maps?q=",LAT,",",LONG
 QUIT
 
DUMP ;
 S F="/tmp/audit-dump.txt"
 C F
 O F:(newversion)
 S A=""
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^AUDIT(A)
 .;I REC["pcr_01_enterprise_pi" U F W !,REC
 .U F W REC,!
 .QUIT
 C F
 QUIT
 
COUNT ;
 S (A,B,C,T)=""
 F  S A=$O(^TZ(A)) Q:A=""  D
 .F  S B=$O(^TZ(A,B)) Q:B=""  D
 ..F  S C=$O(^TZ(A,B,C)) Q:C=""  D
 ...;I A=65486,B>28800 Q
 ...S T=T+1
 W !,T
 QUIT
 
START ;
 S A="",COUNT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  D
 .S REC=$G(^AUDIT(A))
 .I REC["ceg_enterprise" W !,A," * ",^AUDIT(A) R *Y
 .QUIT
 QUIT
 
ZAUDIT ;
 S A="",COUNT=0,T=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=$G(^AUDIT(A))
 .I REC["ceg_enterprise" S COUNT=COUNT+1 ; W !,A," * ",REC R *Y
 .I T#100000=0 W !,REC
 .S T=T+1
 .QUIT
 QUIT
 
FLATS ;
 K ^CSV
 S COUNT=2
 S F="/tmp/EPC_NEL_July2020.txt"
 C F
 O F:(readonly)
 S ^CSV(1)="CAND_ADD,UPRN,ID,QUAL"
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .S ADD1=$P(STR,$C(9),3)
 .S ADD2=$P(STR,$C(9),4)
 .S ADD3=$P(STR,$C(9),5)
 .S ID=$P(STR,$C(9),1)
 .S POSTCODE=$P(STR,$C(9),6)
 .S ADR=ADD1_","_ADD2_","_ADD3_","_POSTCODE
 .S ADR=$$TR^LIB(ADR,"""","")
 .;S ADR=$$TR^LIB($P(STR,$C(9),82),"""","")_","_POSTCODE
 .;U 0 W !,ADR R *Y
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .S QUAL=$get(b("Qualifier"))
 .S R=""""_ADR_""","_UPRN_","_ID_","_QUAL
 .S ^CSV(COUNT)=$TR(R,$C(13),"")
 .S COUNT=COUNT+1
 .QUIT
 C F
 S F2="/tmp/flats2020.txt"
 C F2
 O F2:(newversion)
 S C=""
 F  S C=$O(^CSV(C)) Q:C=""  U F2 W ^(C),!
 C F2
 QUIT
 
HOMES ;
 K ^CSV
 S F="/tmp/HOMES.txt"
 CLOSE F
 S F2="/tmp/ch08July2020.txt"
 ;C F2
 ;O F2:(newversion)
 O F:(readonly)
 ;F I=1:1:5 U F R STR
 S C=1
 U F R STR ; HEADERS
 F  U F R STR Q:$ZEOF  DO
 .;S ADDRESS=$P($P(STR,",""",2),""",")
 .;S POSTCODE=$P($P(STR,""",",2),",")
 .;U 0 W !,ADDRESS," * ",POSTCODE R *Y
 .S ID=$P(STR,",",$L(STR,","))
 .;U 0 W !,"[",ID,"]" R *Y
 .S STR=$P(STR,",",1,$L(STR,",")-1)
 .;U 0 W !,ID," * ",STR
 .;R *Y
 .D GETUPRN^UPRNMGR(STR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .set ALG=$TR($get(b("Algorithm")),$C(13),"")
 .S QUAL=$get(b("Qualifier"))
 .S R=""""_STR_""","_UPRN_","_ID_","_ALG_","_QUAL
 .S ^CSV(C)=$TR(R,$C(13),"")
 .S C=C+1
 .QUIT
 CLOSE F
 C F2
 O F2:(newversion)
 S C=""
 F  S C=$O(^CSV(C)) Q:C=""  U F2 W ^(C),!
 C F2
 QUIT
 
INDEX ;
 S A="",COUNT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=$G(^AUDIT(A))
 .I REC["ceg_enterprise" DO
 ..S R=$P(REC,"|",2)
 ..S PATID=$P(R,"`",1)
 ..S I=$O(^II(PATID,""),-1)+1
 ..S ^II(PATID,I)=REC
 ..S COUNT=COUNT+1
 ..I COUNT#100000=0 W !,REC ; W !,"STOP:" R *Y
 ..QUIT
 .QUIT
 QUIT
 
CEG2 ;
 K ^TDONE
 S A="",TOT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^(A)
 .;I $P($P(REC,"|",2),"`",3)'="hurley_deidentified" Q
 .I REC'["hurley" QUIT
 .S TOT=TOT+1
 .;W !,REC R *Y
 .S UPRN=$P(REC,"|",1)
 .I UPRN'="" QUIT
 .S DATE=$P(REC,"|",4)
 .;I $P(DATE,",",1)'=65469 QUIT
 .;W !,REC
 .S H=$P(DATE,","),T=$P(DATE,",",2)
 .;W !,REC
 .;W !,$$HD^STDDATE(H)," ",$$HT^STDDATE(T)
 .;I H>65484 S ZID=$O(^TZ(H,T,""),-1)+1 S ^TZ(H,T,ZID)=""
 .S ADDR=$P(REC,"|",3)
 .S KEY=$P(REC,"|",2)
 .S ^TDONE(ADDR)=KEY
 .;S T=T+1
 .QUIT
 
 S F="/tmp/addr-2.txt"
 C F
 O F:(newversion)
 S A=""
 F  S A=$O(^TDONE(A)) Q:A=""  D
 .U F W A,"~",^TDONE(A),!
 .QUIT
 C F
 
 W !,TOT
 
 QUIT
CEG ;
 K ^TDONE
 S file="/tmp/ceg_data_checking.csv"
 close file
 o file:(readonly):0
 U file r STR
 f i=1:1 use file read STR Q:$zeof  do
 .S ID=$p(STR,",",1)
 .;I $D(^TDONE(ID)) QUIT
 .; LOOP DOWN ^AUDIT TO GET THE ADDRESS LINES
 .D AUDIT(ID)
 .;S ^TDONE(ID)=""
 .quit
 c file
 QUIT
AUDIT(ID) ;
 S Z=""
 F  S Z=$O(^AUDIT(Z)) Q:Z=""  D
 .S ZID=$p($p(^(Z),"|",2),"`",1)
 .;U 0 W !,ZID
 .I ZID=ID D
 ..S ADDR=$P(^AUDIT(Z),"|",3)
 ..S ^TDONE(ADDR)=""
 ..U 0 W !,^AUDIT(Z)
 ..QUIT
 .QUIT
 Q
