PS ; ; 3/29/21 12:38pm
 S A="",C=0
 F  S A=$O(^CQC(A)) Q:A=""  DO
 .S J=""
 .F I=1:1:10 S J1=$G(^CQC(A,I)) Q:J1=""  S J=J_J1
 .;W !,J R *Y
 .D DECODE^VPRJSON($name(J),$name(b),$name(err))
 .S ADR=$get(b("address",1,"text"))
 .;W !,ADR R *Y
 .K ^TPARAMS($J),^TUPRN($J)
 .S ^TPARAMS($J,"commercials")=1
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .;W !,^temp($j,1)
 .S C=C+1
 .I C#1000=0 W !,C
 .QUIT
 QUIT
 
 K ^NELPOST
 S F="/tmp/POSTCODE_ABP_CCG.txt"
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO
 .S ^NELPOST($TR(STR,$C(13),""))=""
 .QUIT
 CLOSE F
 QUIT
 
CQC K ^CQC
 ;S F="/tmp/UPRN3_globals/CQC.gs"
 S F="/tmp/CQC.gs"
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .;U 0 R *Y
 .U F R DATA
 .;U 0 W !,STR
 .;U 0 W !,DATA
 .;U 0 R *Y
 .;S X=$$TR^LIB(STR,"""","""""")
 .;X STR
 .S X="S "_STR_"=DATA"
 .X X
 .U 0 W "."
 .QUIT
 C F
 QUIT
 
CLR ;
 S A=""
 F  S A=$O(^CQC(A)) Q:A=""  DO
 .S H=+^CQC(A,"H")
 .I H'=65763 K ^CQC(A)
 .QUIT
 Q
 
 S A=""
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO
 .S REC=^(A)
 .S DAT=$P(REC,"|",4)
 .S CONFIG=$P($P(REC,"|",2),"`",2)
 .I $P(DAT,",",1)=65552 W !,CONFIG," * ",DAT R *Y
 .QUIT
 QUIT
 
 K ^PS
 S (A,B)=""
 F  S A=$O(^UPRN(A)) Q:A=""  D
 .F  S B=$O(^UPRN(A,B)) Q:B=""  D
 ..S ^PS(A)=$G(^PS(A))+1
 ..Q
 .QUIT
 W $D
 QUIT
