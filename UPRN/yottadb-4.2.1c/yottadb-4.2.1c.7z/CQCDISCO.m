CQCDISCO ; ; 3/18/21 11:36am
 ;S F="/tmp/cqc_api-4.csv.txt"
 ;S F2="/tmp/cqc_name-also-v3.txt"
 S F="/tmp/cqc_api-1a.csv.txt"
 S F2="/tmp/cqc_name-also-v5.txt"
 C F
 O F:(readonly)
 O F2:(newversion)
 new d
 S d=$C(9)
 USE F2 W "cqc_address",d,"postcode",d,"cqc_uprn",d,"disco_uprn",d,"cqc_name",d,"cqc_also",d,"uprn_disco_name",d,"uprn_disco_also",d,"care_home",d,"reg_status",d,"diff",!
 ;
 S C=0
 K ^TST
 F  U F R STR Q:$ZEOF  DO  ; Q:C>10
 .;U 0 W !,STR
 .S CQCUPRN=$P(STR,$C(9),20)
 .S ADR=$P(STR,$C(9),4)
 .S POSTCODE=$P(STR,$C(9),5)
 .; NEL POST CODE?
 .S A=$P(POSTCODE," ")
 .I '$D(^NELPOST(A)) QUIT
 .S NAME=$P(STR,$C(9),2)
 .S ALSO=$P(STR,$C(9),3)
 .S CAREHOME=$P(STR,$C(9),18)
 .S REG=$P(STR,$C(9),22)
 .;U 0 W !,"CQC_UPRN: ",CQCUPRN
 .;U 0 W !,"CQC_ADDRESS: ",ADR
 .;U 0 W !,"CQC_POSTCODE: ",POSTCODE
 .;U 0 W !,"CQC_NAME: ",NAME
 .;U 0 W !,"ALSO: ",ALSO
 .;U 0 W !,"CARE HOME: ",CAREHOME
 .;U 0 R *Y
 .S (NAMEUPRN,ALSOUPRN)=""
 .S DISCOUPRN=$$GETUPRN(ADR_","_POSTCODE)
 .;W !,"DISCO_UPRN=",DISCOUPRN
 .I NAME'="" DO
 ..S NAMEADR=NAME_","_ADR_","_POSTCODE
 ..;
 ..;
 ..;
 ..;
 ..S NAMEUPRN=$$GETUPRN(NAMEADR)
 ..;U 0 W !,"NAME_UPRN: ",NAMEUPRN
 ..QUIT
 .I ALSO'="" DO
 ..S ALSOADR=ALSO_","_ADR_","_POSTCODE
 ..;
 ..; 
 ..S ALSOUPRN=$$GETUPRN(ALSOUPRN)
 ..;U 0 W !,"ALSO_UPRN:",ALSOUPRN
 ..;
 ..;
 ..QUIT
 .S d=$c(9)
 .;
 .;
 .S DIFF=""
 .;I DISCOUPRN'="",CQCUPRN'=DISCOUPRN S DIFF="*"
 .;I NAMEUPRN'="",CQCUPRN'=NAMEUPRN S DIFF="*"
 .;I ALSOUPRN'="",CQCUPRN'=ALSOUPRN S DIFF="*"
 .I NAMEUPRN'="",NAMEUPRN'=DISCOUPRN S DIFF="*"
 .I DIFF="*",CQCUPRN=NAMEUPRN S DIFF="**"
 .;
 .S ^NELUPRN("CQC",CQCUPRN)=""
 .S ^NELUPRN("DISCO",DISCOUPRN)=""
 .S ^NELUPRN("NAME",NAMEUPRN)=""
 .;
 .U F2 W ADR,d,POSTCODE,d,CQCUPRN,d,DISCOUPRN,d,NAME,d,ALSO,d,NAMEUPRN,d,ALSOUPRN,d,CAREHOME,d,REG,d,DIFF,!
 .S C=$I(C)
 .I C#100=0 U 0 W !,C
 .QUIT
 C F
 CLOSE F2
 QUIT
 
GETUPRN(ZADR) 
 K ^TPARAMS($J)
 S ^TPARAMS($J,"commercials")=1
 D GETUPRN^UPRNMGR(ZADR,"","","",0,0)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 S UPRN=$get(b("UPRN"))
 QUIT UPRN
 
ABP ; TEST
 F NODE="CQC","DISCO","NAME" DO
 .S UPRN=""
 .F  S UPRN=$O(^NELUPRN(NODE,UPRN)) Q:UPRN=""  DO
 ..;W !,UPRN
 ..S REC=$GET(^UPRN("U",UPRN))
 ..S COORD=$P(REC,"~",7)
 ..S X=$P(COORD,",",1),Y=$P(COORD,",",2)
 ..;W !,UPRN," * ",X," * ",Y
 ..S KEY=$O(^UPRN("U",UPRN,"D",""))
 ..S ADREC=""
 ..I KEY'="" S ADREC=$GET(^UPRN("U",UPRN,"D",KEY,"O"))
 ..;
 ..S KEY=$O(^UPRN("U",UPRN,"L",""))
 ..S LREC=""
 ..I KEY'="",ADREC="" S ADREC=$GET(^UPRN("U",UPRN,"L",KEY,"O")),LREC=ADREC
 ..S ADR=""
 ..F I=1:1:$L(ADREC,"~") S:$P(ADREC,"~",I)'="" ADR=ADR_$P(ADREC,"~",I)_","
 ..W !,UPRN
 ..;W !,ADR
 ..S LEVEL=$P(LREC,"~",10)
 ..W !,LEVEL
 ..QUIT
 QUIT
