The M code prior to upgrading to 4.2.1
The code was copied from UPRN3