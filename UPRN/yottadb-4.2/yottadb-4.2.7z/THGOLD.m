THGOLD ; ; 8/7/20 10:33am
 K ^PS
 ;S F="/tmp/UPRN-TH 3-9.txt"
 ;S F2="/tmp/UPRN-TH 3-9-out.csv"
 S F="/tmp/TH_GoldStandard_Nov19.csv"
 S F2="/tmp/TH_GoldStandard_Nov19-out.csv"
 C F
 O F:(readonly)
 O F2:(newversion)
 U F2 W "id,algorithm,match_patt_build,match_patt_flat,"
 U F2 W "match_patt_number,match_patt_postcode,qualifier,"
 U F2 W "uprn,classification,status,candidate_address",!
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .;S ID=$P(STR,$C(9))
 .S ID=$P(STR,",")
 .;S CADR=$$TR^LIB($P(STR,$C(9),7),"""","")
 .S CADR=$P(STR,",",3,99)
 .;U 0 W !,CADR
 .S CADR=$TR(CADR,$C(13),"")
 .I CADR="" Q
 .K B,^temp($j)
 .D GETUPRN^UPRNMGR(CADR,"","","",0,0)
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(B),$name(err))
 .S ALG=$G(B("Algorithm"))
 .S MPBUILD=$G(B("Match_pattern","Building"))
 .S MPFLAT=$G(B("Match_pattern","Flat"))
 .S MPNUM=$G(B("Match_pattern","Number"))
 .S MPPCODE=$G(B("Match_pattern","Postcode"))
 .S QUAL=$G(B("Qualifier"))
 .S UPRN=$G(B("UPRN"))
 .S CLASS=$piece($get(^UPRN("CLASS",UPRN)),"~",1)
 .S STATUS=$P($get(^UPRN("U",UPRN)),"~",3)
 .I UPRN="" S ^PS($O(^PS(""),-1)+1)=CADR
 .U F2 W ID,",",ALG,",",MPBUILD,",",MPFLAT,",",MPNUM,",",MPPCODE,",",QUAL,",",UPRN,",",CLASS,",",STATUS,",""",CADR,",""",!
 .;R *Y
 .;
 .QUIT
 C F,F2
 QUIT
