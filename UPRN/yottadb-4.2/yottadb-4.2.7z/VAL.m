VAL ;  ; 8/25/20 10:18am
 ;K ^EXP
VER W !,"epoch version? "
 R EPOCH
 I EPOCH="." Q
 I EPOCH="" G VER
 S F="/tmp/ceg_gp.txt"
 C F
 O F:(readonly)
 S C=0,D=0
 F  U F R STR Q:$ZEOF  DO  ;; Q:C>1000000
 .;U 0 W !,STR R *Y
 .S ZUPRN=$P(STR,"~")
 .I ZUPRN="" QUIT
 .S ZADR=$P(STR,"~",2,99)
 .k a
 .S a("adrec")=ZADR
 .S a("delim")="~"
 .D GETCSV(.r,.a)
 .S REC=^TMP($J,1)
 .S UPRN=$PIECE(REC,"~",21)
 .;BREAK
 .I ZUPRN'=UPRN U 0 W !,ADR,!,"BEFORE: ",ZUPRN,!,"AFTER: ",UPRN,!,^TMP($J,1) S D=D+1 S ^EXP(EPOCH,ZUPRN,UPRN)=ZADR ; R *Y
 .I C#1000=0 U 0 W !,C
 .S C=C+1
 .QUIT
 C F
 QUIT
 
O ;
 S EPOCH=76,C=0
 W "ABPLocality,ABPNumber,ABPOrganization,"
 W "ABPPostcode,ABPStreet,ABPTown,"
 W "algorithm,qualifier,match_pattern_building,"
 W "match_pattern_Flat,"
 W "match_pattern_Number,"
 W "match_pattern_postcode,"
 W "match_pattern_street,"
 W "address_format," ; quality
 W "latitude,"
 W "longitude,"
 W "x,"
 W "y,"
 W "classification,"
 W "uprn,baseline_uprn,candidate_address",!
 S H="ABPLocality,ABPNumber,ABPOrganization,"
 S H=H_"ABPPostcode,ABPStreet,ABPTown,"
 S H=H_"algorithm,qualifier,match_pattern_building,"
 S H=H_"match_pattern_Flat,"
 S H=H_"match_pattern_Number,"
 S H=H_"match_pattern_postcode,"
 S H=H_"match_pattern_street,"
 S H=H_"address_format,"
 S H=H_"latitude,"
 S H=H_"longitude,"
 S H=H_"x,"
 S H=H_"y,"
 S H=H_"classification,"
 S H=H_"uprn,baseline_uprn,candidate_address,cterm"
 K ^CSV
 S (ZUPRN,UPRN)="",C=1
 S ^CSV(C)=H,C=C+1
 S UPRN=-1
 S G="^EXP"
 F  S G=$Q(@G) Q:G=""  DO
 .S ADDCAND=@G
 .S ZUPRN=$P(G,",",2)
 .D CSV(ADDCAND,ZUPRN)
 .QUIT
 D W
 QUIT
 
 F  S ZUPRN=$O(^EXP(EPOCH,ZUPRN)) Q:ZUPRN=""  DO
 .;S QF=0
 .I $DATA(^EXP(EPOCH,ZUPRN,"")) D  Q
 ..S ADDCAND=^EXP(EPOCH,ZUPRN,"")
 ..D CSV(ADDCAND,ZUPRN)
 ..QUIT
 .F  S UPRN=$NEXT(^EXP(EPOCH,ZUPRN,UPRN)) Q:UPRN=-1  DO
 ..S ADDCAND=^(UPRN)
 ..D CSV(ADDCAND,ZUPRN)
 ..Q
 .Q
 D W ; write ^CSV to disk
 QUIT
 
 ; D MERGE^VAL("/tmp/epoch76.csv","^EPOCH76")
 ; D MERGE^VAL("/tmp/live.csv","^LIVE")
GM ;
A W !,"epoch number? "
 R EPOCH
 I EPOCH'?1n.n G A
 
 ;QUIT
 
 S F="/tmp/epoch"_EPOCH_".csv"
 S X=$$10^ZOS(F)
 I X>1 G A
 I $$10^ZOS("/tmp/live.csv")>1 W !,"/tmp/live.csv does not exist" QUIT
 D MERGE(F,"^EPOCH"_EPOCH)
 D MERGE("/tmp/live.csv","^LIVE")
 D X
 QUIT
 
MERGE(F,GLOB) ;
 ;S F="/tmp/live.csv"
 K @GLOB
 C F
 O F:(readonly)
 F  U F R STR Q:$ZEOF  DO
 .;U 0 W !,STR
 .S CADDR=$P($P(STR,",""",2),""",")
 .;S CADDR=$E(CADDR,1,$L(CADDR)-1)
 .U 0 W !,CADDR
 .S @GLOB@(CADDR)=STR
 .QUIT
 C F
 QUIT
 
X ;
 S H="ABPLocality,ABPNumber,ABPOrganization,ABPPostcode,ABPStreet,ABPTown,algorithm,qualifier,match_pattern_building,match_pattern_Flat,match_pattern_Number,match_pattern_postcode,match_pattern_street,address_format,latitude,longitude,x,y,classification,uprn,baseline_uprn,candidate_address,cterm"
 
 S F="/tmp/x.csv"
 C F
 O F:(newversion)
 S CADDR=""
 USE F
 W H,!
 F  S CADDR=$O(^LIVE(CADDR)) Q:CADDR=""  D
 .W ^LIVE(CADDR),!
 .W ^EPOCH76(CADDR),!
 .W !
 .QUIT
 CLOSE F
 QUIT
 
CSV(ADDCAN,ZUPRN) 
 ; RUN THE ALGORITHM
 D GETUPRN^UPRNMGR(ADDCAND,"","","",0,0)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 ;w !
 ;zwr b
 ;W !,ZUPRN," ",UPRN,",",ADDCAND
 K A
 S A("adrec")=ADDCAND
 D GETCSV(.R,.A)
 S CSV=$P(^TMP($J,1),",",1,16)_","_$P(^TMP($J,1),",",18,21)
 S CLASS=$P(^TMP($J,1),",",20)
 ;BREAK
 S CTERM=$GET(^UPRN("CLASSIFICATION",CLASS,"term"))
 S CSV=CSV_","_ZUPRN_","""_ADDCAND_""","_CTERM
 S ^CSV(C)=CSV
 S C=C+1
 W $P(^TMP($J,1),",",1,16),",",$P(^TMP($J,1),",",18,21)
 ;S $P(^TMP($J,1),",",21)="'"_$P(^TMP($J,1),",",21)
 W ",",ZUPRN,",""",ADDCAND,"""",!
 S C=C+1
 QUIT
 
W ;
 S EPOCH=""
 W !,"Live or Dev (L/D)? "
 R LD#1
 I "/L/D/"'[("/"_LD_"/") G W
 I LD="D" DO
EPOCH .W !,"epoch number? "
 .R EPOCH
 .I EPOCH'?1n.n G EPOCH
 .QUIT
 S F="/tmp/epoch"_EPOCH_".csv"
 I LD="L" S F="/tmp/live.csv"
 S C=""
 ;S F="/tmp/epoch76.csv"
 O F:(newversion)
 F  S C=$O(^CSV(C)) Q:C=""  DO
 .U F W ^(C),!
 .QUIT
 C F
 QUIT
 ;
 S a("adrec")="45B,ZEALAND ROAD,LONDON,E35RA"
 S a("del")="~"
 D GETCSV(.r,.a)
 zwr r
 QUIT
 
GETCSV(result,arguments) 
 K ^TMP($J)
 S CR=$C(13,10)
 ;
 set adrec=$Get(arguments("adrec"))
 set del=$Get(arguments("delim"))
 set ids=$Get(arguments("ids"))
 i $g(del)="" s del=","
 K json
 K ^temp($j)
 ;D GETUPRN^UPRNMGR(adrec)
 D GETUPRN^UPRNMGR(adrec,"","","",0,0)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 set UPRN=$get(b("UPRN"))
 set ALG=$get(b("Algorithm"))
 set QUAL=$get(b("Qualifier"))
 set MATPATBUILD=$get(b("Match_pattern","Building"))
 set MATPATFLAT=$get(b("Match_pattern","Flat"))
 set MATPATNUMBER=$get(b("Match_pattern","Number"))
 set MATPATPSTCDE=$get(b("Match_pattern","Postcode"))
 set MATPATSTRT=$get(b("Match_pattern","Street"))
 set QUALITY=$get(b("Address_format"))
 S (COORD,LAT,LONG,POINT,X,Y,CLASS)=""
 if UPRN'="" do
 .;S ^FRED($O(^FRED(""),-1)+1)=UPRN_"~"_$A(UPRN)
 .S COORD=$piece($get(^UPRN("U",UPRN)),"~",7)
 .S LAT=$P(COORD,",",3),LONG=$P(COORD,",",4)
 .S POINT=$P(COORD,",",3),X=$P(COORD,",",1),Y=$P(COORD,",",2)
 .S CLASS=$piece($get(^UPRN("CLASS",UPRN)),"~",1)
 .quit
 S LOCALITY=$get(b("ABPAddress","Locality"))
 S NUMBER=$g(b("ABPAddress","Number"))
 S ORG=$g(b("ABPAddress","Organisaton"))
 S POSTCODE=$g(b("ABPAddress","Postcode"))
 S STREET=$g(b("ABPAddress","Street"))
 S TOWN=$g(b("ABPAddress","Town"))
 s csv=LOCALITY_del_NUMBER_del_ORG_del_POSTCODE_del_STREET_del_TOWN
 set csv=csv_del_ALG_del_QUAL_del_MATPATBUILD_del_MATPATFLAT_del
 s csv=csv_MATPATNUMBER_del_MATPATPSTCDE_del_MATPATSTRT_del
 s csv=csv_QUALITY_del_$g(LAT)_del_$g(LONG)_del_$g(POINT)_del_$g(X)_del_$g(Y)_del_$g(CLASS)_del_UPRN
 s ^TMP($J,1)=csv
 set result("mime")="text/plain, */*"
 set result=$na(^TMP($j)) 
 s ^TMP($J,1)=csv
 set result("mime")="text/plain, */*"
 set result=$na(^TMP($j))
 QUIT
