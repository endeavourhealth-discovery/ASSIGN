DS ; ; 12/16/20 9:15am
 S A=""
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO
 .S REC=^(A)
 .I REC'["internal" QUIT
 .S ID=$P($P(REC,"|",2),"`",1)
 .I ID=478 W !,REC R *Y
 .QUIT
 QUIT
 
 S A="",(Z,C,QF)=0
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO  Q:QF
 .S REC=^AUDIT(A)
 .S DAT=+$P(REC,"|",$L(REC,"|"))
 .I DAT<65728 S QF=1 Q
 .I REC["internal" S C=C+1
 .I REC["internal",$P(REC,"|")="" S Z=Z+1
 .QUIT
 QUIT
 
 K ^TPARAMS($J)
 S F="/tmp/100000.txt",C=0
 S F2="/tmp/100000_out_uprn3.txt"
 C F2,F
 O F:(readonly)
 O F2:(newversion)
 F  U F R STR Q:$ZEOF  DO  ;;Q:C>10
 .S ADR=$P(STR,",",2,9999)
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .S UPRN=$get(b("UPRN"))
 .U F2 W !,UPRN,"~",ADR,"~",$g(^temp($j,1))
 .S C=C+1
 .I C#1000=0 U 0 W !,C
 .QUIT
 CLOSE F,F2
 QUIT
 
 S FILE="",C=""
 F  S FILE=$O(^CSV(FILE)) Q:FILE=""  DO
 .S COMM=^CSV(FILE)
 .S F2="/tmp/"_FILE_"-"_COMM_".txt"
 .C F2
 .O F2:(newversion)
 .F  S C=$O(^CSV(FILE,C)) Q:C=""  DO
 ..USE F2
 ..W $TR(^(C),$C(13),""),!
 ..QUIT
 .CLOSE F2
 .QUIT
 QUIT
 
ORGS ;
 W !,"COMMERCIAL? (Y/N)"
 R COMM
 W !
 K ^TPARAMS($J)
 K ^TPARAMS($J,"commercials")
 I COMM="Y" S ^TPARAMS($J,"commercials")=1
 K ^CSV
 F F="ODS-ADDRESSES.TXT","CQC-ADDRESSES.TXT" D
 .S C=1
 .S F2="/tmp/"_F
 .C F2
 .O F2:(readonly)
 .S ^CSV($P(F,"-"))=COMM
 .F  U F2 R STR Q:$ZEOF  DO
 ..U 0 W !,STR
 ..S ADREC=$P(STR,"~",2)
 ..S ID=$P(STR,"~",1)
 ..D GETUPRN^UPRNMGR(ADREC,"","","",0,0)
 ..K b
 ..D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 ..set UPRN=$get(b("UPRN"))
 ..U 0 W UPRN,!
 ..S ^CSV($P(F,"-"),C)=UPRN_"~"_ADREC_"~"_ID_"~"_^temp($j,1)
 ..S C=C+1
 ..QUIT
 .CLOSE F2
 .QUIT
 QUIT
ALG ;
 S A=""
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO
 .S REC=^(A)
 .I REC'["nwl_kd" QUIT
 .S DAT=$P(REC,"|",4)
 .S H=$P(DAT,","),T=$P(DAT,",",2)
 .I H'=65707 QUIT
 .I T<(60300-50) QUIT
 .I T>(60300+50) QUIT
 .S ADR=$P(REC,"|",3)
 .w !!
 .W ADR,!
 .W $$DH^DAT(H)," * ",$$TH^DAT(T),!
 .D GETUPRN^UPRNMGR(ADR,"","","",0,1)
 .R *Y
 .QUIT
 QUIT
 
 S A="",DIFF=0,TOT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^AUDIT(A)
 .S ADR=$P(REC,"|",3)
 .;W !,ADR R *Y
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .;w !,UPRN," AUDIT = ",$P(REC,"|")
 .;R *Y
 .I UPRN'=$P(REC,"|") W !,UPRN,"'=",$P(REC,"|",1)," * ",A," * ",ADR S DIFF=DIFF+1 ; R *Y
 .S TOT=TOT+1
 .QUIT
 QUIT
 
CCG ;
 S C=0
 S F="/tmp/QA-1.txt"
 S F2="/tmp/QA-2-OUT.txt"
 CLOSE F,F2
 S CAND="Flat 18 Western Beach Apartment,36 Hanover Avenue,,,London,E161DW"
 O F:(readonly)
 O F2:(newversion)
 S GO=0
 F  U F R STR Q:$ZEOF  DO
 .S ADR=$P(STR,"~",1)
 .I ADR=CAND S GO=1 U 0 W !,"SETTING GO TO 1" QUIT
 .I GO=0 QUIT
 .;U 0 W !,ADR
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .U F2 W !,ADR,"~",^temp($j,1)
 .S C=C+1
 .I C#1000=0 U 0 W !,C
 .QUIT
 CLOSE F,F2
 QUIT
 
A R !,"ADDRESS: ",ADR
 W !
 K ^TPARAMS($J)
 S ^TPARAMS($J,"commercials")=1
 D GETUPRN^UPRNMGR(ADR,"","","",0,1)
 K b
 D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 S UPRN=$G(b("UPRN"))
 W !,$P($G(^UPRN("U",UPRN)),"~",7)
 QUIT
 
DUMP ;
 S F="/tmp/audit_ceg_gp.txt"
 C F
 O F:(newversion)
 S A="",C=0
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO  Q:C>1000000
 .S REC=^AUDIT(A)
 .;I REC["pcr_01_enterprise_pi" U F W !,REC
 .;I REC["`ceg_enterprise|" U F W REC,! S C=C+1
 .I REC["`ceg_gp|" U F W REC,! S C=C+1
 .QUIT
 C F
 QUIT
 
COUNT ;
 S (A,B,C,T)=""
 F  S A=$O(^TZ(A)) Q:A=""  D
 .F  S B=$O(^TZ(A,B)) Q:B=""  D
 ..F  S C=$O(^TZ(A,B,C)) Q:C=""  D
 ...;I A=65486,B>28800 Q
 ...S T=T+1
 W !,T
 QUIT
 
START ;
 S F="/tmp/ceg_gp_16112020.txt"
 C F
 O F:(newversion)
 S A="",COUNT=0,QF=0
 F  S A=$O(^AUDIT(A),-1) Q:A=""  D  Q:QF
 .S REC=$G(^AUDIT(A))
 .S DAT=$P(REC,"|",4)
 .S H=$P(DAT,",")
 .I H<65697 S QF=1 QUIT
 .;W !,DAT R *Y
 .;I REC["ceg_enterprise" W !,A," * ",^AUDIT(A) R *Y
 .I REC["ceg_gp" S COUNT=COUNT+1 U F W REC,!
 .QUIT
 C F
 QUIT
 
ZAUDIT ;
 S A="",COUNT=0,T=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=$G(^AUDIT(A))
 .I REC["ceg_enterprise" S COUNT=COUNT+1 ; W !,A," * ",REC R *Y
 .I T#100000=0 W !,REC
 .S T=T+1
 .QUIT
 QUIT
 
FLATS ;
 K ^CSV
 S COUNT=1
 S F="/tmp/EPC_NEL-2008-April2020.txt"
 C F
 O F:(readonly)
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .S ADD1=$P(STR,$C(9),2)
 .S ADD2=$P(STR,$C(9),3)
 .S ADD3=$P(STR,$C(9),4)
 .S ID=$P(STR,$C(9),1)
 .S POSTCODE=$P(STR,$C(9),5)
 .;S ADR=ADD1_","_ADD2_","_ADD3_","_POSTCODE
 .S ADR=$$TR^LIB($P(STR,$C(9),82),"""","")_","_POSTCODE
 .;U 0 W !,ADR
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .S QUAL=$get(b("Qualifier"))
 .S R=""""_ADR_""","_UPRN_","_ID_","_QUAL
 .S ^CSV(COUNT)=$TR(R,$C(13),"")
 .S COUNT=COUNT+1
 .QUIT
 C F
 S F2="/tmp/flats.txt"
 C F2
 O F2:(newversion)
 S C=""
 F  S C=$O(^CSV(C)) Q:C=""  U F2 W ^(C),!
 C F2
 QUIT
 
HOMES ;
 K ^CSV
 S F="/tmp/HOMES.txt"
 CLOSE F
 S F2="/tmp/out.txt"
 ;C F2
 ;O F2:(newversion)
 O F:(readonly)
 ;F I=1:1:5 U F R STR
 S C=1
 F  U F R STR Q:$ZEOF  DO
 .;S ADDRESS=$P($P(STR,",""",2),""",")
 .;S POSTCODE=$P($P(STR,""",",2),",")
 .;U 0 W !,ADDRESS," * ",POSTCODE R *Y
 .S ID=$P(STR,",",$L(STR,","))
 .;U 0 W !,"[",ID,"]" R *Y
 .S STR=$P(STR,",",1,$L(STR,",")-1)
 .;U 0 W !,ID," * ",STR
 .;R *Y
 .D GETUPRN^UPRNMGR(STR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .set ALG=$TR($get(b("Algorithm")),$C(13),"")
 .S QUAL=$get(b("Qualifier"))
 .S R=""""_STR_""","_UPRN_","_ID_","_ALG_","_QUAL
 .S ^CSV(C)=$TR(R,$C(13),"")
 .S C=C+1
 .QUIT
 CLOSE F
 C F2
 O F2:(newversion)
 S C=""
 F  S C=$O(^CSV(C)) Q:C=""  U F2 W ^(C),!
 C F2
 QUIT
 
INDEX ;
 S A="",COUNT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=$G(^AUDIT(A))
 .I REC["ceg_enterprise" DO
 ..S R=$P(REC,"|",2)
 ..S PATID=$P(R,"`",1)
 ..S I=$O(^II(PATID,""),-1)+1
 ..S ^II(PATID,I)=REC
 ..S COUNT=COUNT+1
 ..I COUNT#100000=0 W !,REC ; W !,"STOP:" R *Y
 ..QUIT
 .QUIT
 QUIT
 
CEG2 ;
 K ^TDONE
 S A="",TOT=0
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^(A)
 .;I $P($P(REC,"|",2),"`",3)'="hurley_deidentified" Q
 .I REC'["hurley" QUIT
 .S TOT=TOT+1
 .;W !,REC R *Y
 .S UPRN=$P(REC,"|",1)
 .I UPRN'="" QUIT
 .S DATE=$P(REC,"|",4)
 .;I $P(DATE,",",1)'=65469 QUIT
 .;W !,REC
 .S H=$P(DATE,","),T=$P(DATE,",",2)
 .;W !,REC
 .;W !,$$HD^STDDATE(H)," ",$$HT^STDDATE(T)
 .;I H>65484 S ZID=$O(^TZ(H,T,""),-1)+1 S ^TZ(H,T,ZID)=""
 .S ADDR=$P(REC,"|",3)
 .S KEY=$P(REC,"|",2)
 .S ^TDONE(ADDR)=KEY
 .;S T=T+1
 .QUIT
 
 S F="/tmp/addr-2.txt"
 C F
 O F:(newversion)
 S A=""
 F  S A=$O(^TDONE(A)) Q:A=""  D
 .U F W A,"~",^TDONE(A),!
 .QUIT
 C F
 
 W !,TOT
 
 QUIT
CEG ;
 K ^TDONE
 S file="/tmp/ceg_data_checking.csv"
 close file
 o file:(readonly):0
 U file r STR
 f i=1:1 use file read STR Q:$zeof  do
 .S ID=$p(STR,",",1)
 .;I $D(^TDONE(ID)) QUIT
 .; LOOP DOWN ^AUDIT TO GET THE ADDRESS LINES
 .D AUDIT(ID)
 .;S ^TDONE(ID)=""
 .quit
 c file
 QUIT
AUDIT(ID) ;
 S Z=""
 F  S Z=$O(^AUDIT(Z)) Q:Z=""  D
 .S ZID=$p($p(^(Z),"|",2),"`",1)
 .;U 0 W !,ZID
 .I ZID=ID D
 ..S ADDR=$P(^AUDIT(Z),"|",3)
 ..S ^TDONE(ADDR)=""
 ..U 0 W !,^AUDIT(Z)
 ..QUIT
 .QUIT
 Q
