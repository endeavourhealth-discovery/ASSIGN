DS1 ; ; 5/18/20 9:29am
 K ^CSV
 S C=1
 S F="/tmp/Addresses_Carmarthenshire (1).csv"
 C F
 O F:(readonly)
 U F R STR
 F  U F R STR Q:$ZEOF  DO
 .S ID=$P(STR,",",1)
 .S SYS=$P(STR,",",2)
 .S ADR=$P(STR,",",3,99)
 .D GETUPRN^UPRNMGR(ADR,"","","",0,0)
 .K b
 .D DECODE^VPRJSON($name(^temp($j,1)),$name(b),$name(err))
 .set UPRN=$get(b("UPRN"))
 .S QUAL=$get(b("Qualifier"))
 .S ALG=$get(b("Algorithm"))
 .S MBUILD=$GET(b("Match_pattern","Building"))
 .S MFLAT=$GET(b("Match_pattern","Flat"))
 .S MNUMBER=$GET(b("Match_pattern","Number"))
 .S MPOSTCODE=$GET(b("Match_pattern","Postcode"))
 .S MSTREET=$GET(b("Match_pattern","Street"))
 .;S ^CSV(C)=ID_","_ADR_","_UPRN_","_QUAL_","_ALG_","_MBUILD_","_MFLAT_","_MNUMBER_","_MPOSTCODE_","_MSTREET
 .S REC=ID_","_ADR_","_UPRN_","_QUAL_","_ALG_","_MBUILD_","_MFLAT_","_MNUMBER_","_MPOSTCODE_","_MSTREET
 .S REC=$TR(REC,$C(13),"")
 .S ^CSV(C)=REC
 .S C=C+1
 .QUIT
OUT S F="/tmp/welsh_output.csv"
 C F
 O F:(writeonly)
 U F W "ID,ADD1,ADD2,ADD3,ADD4,ADD5,POSTCODE,UPRN,QUALIFIER,ALGORITHM,MATCHBUILD,MATCHFLAT,MATCHNUMBER,MATCHPOSTCODE,MATCHSTREET",!
 S C="" F  S C=$O(^CSV(C)) Q:C=""  U F W ^(C),!
 CLOSE F
 Q
