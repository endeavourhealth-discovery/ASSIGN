AUDIT ; ; 3/13/20 2:27pm
 S F="/tmp/AUDIT.txt"
 C F
 O F:(writeonly):0
 USE F
 S ID=""
 F  S ID=$O(^AUDIT(ID)) Q:ID=""  D
 .S REC=^AUDIT(ID)
 .W REC,!
 .QUIT
 C F
 QUIT
