PS ; ; 8/21/20 9:29am
 S A="",C=0
 S F="/tmp/ceg_data_checking.txt"
 C F
 O F:(newversion)
 F  S A=$O(^AUDIT(A)) Q:A=""  DO
 .S REC=^AUDIT(A)
 .I REC'["ceg_data_checking" Q
 .U F W !,REC
 .S C=C+1
 .I C#1000=0 U 0 W !,C
 .QUIT
 CLOSE F
 QUIT
 
CEGGP S A="",C=0
 S F="/tmp/ceg_gp.txt"
 C F
 O F:(newversion)
 F  S A=$O(^AUDIT(A),-1) Q:A=""  DO
 .S REC=$GET(^AUDIT(A))
 .I REC'["ceg_gp" quit
 .I C#1000=0 U 0 W !,C
 .S UPRN=$P(REC,"|",1)
 .U F W UPRN,"~",$P(REC,"|",3),!
 .S C=C+1
 .QUIT
 CLOSE F
 QUIT
 
 K ^PS
 S (A,B)=""
 F  S A=$O(^UPRN(A)) Q:A=""  D
 .F  S B=$O(^UPRN(A,B)) Q:B=""  D
 ..S ^PS(A)=$G(^PS(A))+1
 ..Q
 .QUIT
 W $D
 QUIT
